package com.Bata.mystore.testcases;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.Bata.mystore.base.BaseClass;
import com.Bata.mystore.pageObject.LoginPage;
import com.Bata.mystore.pageObject.indexPage;

public class LoginPageTest extends BaseClass{
  LoginPage currentLoginPage;
  indexPage currentIndexPage;
	
  @BeforeMethod
  public void setup()
  {
	
	  LaunchApp();
	
  }
  @Test
  
  public void LoginTest() throws Throwable
  {    currentIndexPage = new indexPage();
	Thread.sleep(2000);
	currentLoginPage = currentIndexPage.clickSignIn();

	  Thread.sleep(2000);
	  
	  currentLoginPage.loginClick();
	  Thread.sleep(2000);
  }
}
