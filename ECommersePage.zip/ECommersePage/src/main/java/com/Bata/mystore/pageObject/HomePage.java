package com.Bata.mystore.pageObject;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.Bata.mystore.actiondriver.ActionDriver;
import com.Bata.mystore.base.BaseClass;

public class HomePage  extends BaseClass{
     
	@FindBy(xpath="//*[@id=\"search-input-top-bar\"]")
	WebElement Search;
	@FindBy(xpath="/html/body/span/div[3]/header/div[2]/div[2]/div/div/div/div/form/button")
	WebElement searchProductBox;
	
	@FindBy(xpath="//*[@id=\"product-search-results\"]/div/div[2]/div[6]/div[7]/div/div[1]/div[2]/div[1]/a")
	WebElement firstImage;
	
	public HomePage()
	{
		PageFactory.initElements(driver, this);
	}
	
	public ProductPage SearchProduct() throws Throwable {
		
		ActionDriver.type(Search,"snekers");
		
		Thread.sleep(2000);
		ActionDriver.click(driver, searchProductBox);
		Thread.sleep(1000);
//         JavascriptExecutor js=(JavascriptExecutor) driver;
//         
//         js.executeScript("window.scrollTo(0,200");
//         
		
		JavascriptExecutor js = (JavascriptExecutor) driver;

        // Scroll down the page by a specific number of pixels (e.g., 500)
        js.executeScript("window.scrollBy(0, 500);");
       
		ActionDriver.click(driver,firstImage);	
		System.out.println("final");
		Thread.sleep(1000);
		return new ProductPage();
		
	}
	
	//*[@id="slick-slide10"]/div/div/div/picture/img
}
