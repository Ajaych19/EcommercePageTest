package com.Bata.mystore.testcases;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.Bata.mystore.base.BaseClass;
import com.Bata.mystore.pageObject.HomePage;
import com.Bata.mystore.pageObject.LoginPage;
import com.Bata.mystore.pageObject.ProductPage;
import com.Bata.mystore.pageObject.indexPage;


public class ProductPageTest extends BaseClass {
		
	
	
	 @BeforeMethod
	  public void setup()
	  {
		
		  LaunchApp();
		
	  }
	indexPage currentIndexPage;
	LoginPage currentLoginPage;
	HomePage currentHomePage;
	ProductPage currentProductPage;
	@Test
	public void SelectProduct() throws Throwable
	{
		currentIndexPage=new indexPage();

    	System.out.println("hello");
		currentLoginPage=currentIndexPage.clickSignIn();
		currentHomePage=currentLoginPage.loginClick();

    	System.out.println("hello");
		currentProductPage=currentHomePage.SearchProduct();
		
		Thread.sleep(100);
		currentProductPage.AddCart();
		
		Thread.sleep(10000);
    	System.out.println("hello");
    	
		
	}
}
