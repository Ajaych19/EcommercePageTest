package com.Bata.mystore.pageObject;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.Bata.mystore.actiondriver.ActionDriver;
import com.Bata.mystore.base.BaseClass;

public class ProductPage extends BaseClass {
	
	

	
	@FindBy(xpath="//*[@id=\"size-ul-list\"]/li[5]	")
	WebElement size;
	
	@FindBy(xpath="//*[@id=\"maincontent\"]/div/div[1]/div[2]/div[5]/div[4]/div[1]/div/div/button")
	WebElement Addtocart;
	
	
	
	@FindBy(xpath="/html/body/span")
	WebElement checkout;
	
	
	
	@FindBy(xpath="//*[@id=\"cart-page-checkout-btn\"]")
	WebElement procced;
	//*[@id="minicartIcon"]/span[1]/svg/use
	
	//*[@id="cart-page-checkout-btn"]
	public ProductPage()
	{
		PageFactory.initElements(driver,this);
	}
	
	
	public void AddCart() throws InterruptedException
	{
		ActionDriver.click(driver,size);
		Thread.sleep(1000);
		
		

		ActionDriver.click(driver,Addtocart);
		Thread.sleep(1000);
		
		ActionDriver.click(driver,checkout);
		Thread.sleep(100);
		
		ActionDriver.click(driver,procced);
		Thread.sleep(10000);

	}
}
