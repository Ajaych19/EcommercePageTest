package com.Bata.mystore.testcases;

import org.openqa.selenium.WebElement;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.Bata.mystore.actiondriver.ActionDriver;
import com.Bata.mystore.base.BaseClass;

import dev.failsafe.internal.util.Assert;
import com.Bata.mystore.pageObject.*;


public class IndexPageTest extends BaseClass {
	
	indexPage currentIndexPage;
	
	@BeforeMethod
      public void setup()
      {
		
    	  LaunchApp();
    	
      }
     
         
    @Test
      public void loginTest()throws Throwable
      {
    		currentIndexPage = new indexPage();
    		Thread.sleep(2000);
    		currentIndexPage.clickSignIn();
	    	Thread.sleep(10000);
	    	System.out.println("hello");
    	  
      }
    
    


	@AfterMethod
    public  void tearDown()
    {
  	  driver.quit();
    }
     }

