package com.Bata.mystore.pageObject;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.Bata.mystore.actiondriver.ActionDriver;
import com.Bata.mystore.base.BaseClass;

public class LoginPage extends BaseClass{

	@FindBy
	(xpath="//*[@id=\"login-form-email\"]")
	WebElement User;
	
	@FindBy
	(xpath="//*[@id=\"login-form-password\"]")
	WebElement password;
	
	@FindBy
	(xpath="//*[@id=\"maincontent\"]/div[1]/div/div/div[1]/form/button")
	WebElement submitbtn;
	
	
	@FindBy(xpath="/html/body/span/div[3]/header/div[2]/div[1]/div[1]/button[2]/svg")
	WebElement searchProductBox;
	
	@FindBy(xpath ="/html/body/span/div[3]/header/div[2]/div[3]/div/form/button/svg")
	WebElement searchButton;
	
	public LoginPage()
	{
		PageFactory.initElements(driver, this);
	}
	
	public HomePage loginClick() throws Throwable {
		
		Thread.sleep(2000);
		ActionDriver.type(User, prop.getProperty("username"));
		Thread.sleep(2000);
		ActionDriver.type(password, prop.getProperty("password"));
		
		Thread.sleep(2000);
		ActionDriver.click(driver, submitbtn);
		Thread.sleep(10000);
		
		 return new HomePage();
	}
}
