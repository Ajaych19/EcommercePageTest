package com.Bata.mystore.pageObject;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.Bata.mystore.actiondriver.ActionDriver;
import com.Bata.mystore.base.BaseClass;


public class indexPage extends BaseClass{

	@FindBy(xpath="/html/body/span/div[3]/header/div[2]/div[1]/div[2]/a[2]")
	WebElement signInBtn;
	
	@FindBy(xpath="/html/body/span/div[3]/header/div[2]/div[1]/div[1]/button[2]/svg")
	WebElement searchProductBox;
	
	@FindBy(xpath ="/html/body/span/div[3]/header/div[2]/div[3]/div/form/button/svg")
	WebElement searchButton;
	
	public indexPage()
    {
		PageFactory.initElements(driver,this);
	}

  public LoginPage clickSignIn()throws Throwable
  {
	  ActionDriver.click(driver,signInBtn);
	  return new LoginPage();
  }
		
	

}
