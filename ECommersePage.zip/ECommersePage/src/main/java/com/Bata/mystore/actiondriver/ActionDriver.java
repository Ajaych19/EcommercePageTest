package com.Bata.mystore.actiondriver;

import org.openqa.selenium.JavascriptExecutor;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.devtools.idealized.Javascript;
import org.openqa.selenium.interactions.Actions;

import com.Bata.mystore.base.*;
public class ActionDriver extends BaseClass{

	public static void scrollByVisibilityOfElement(WebDriver drive,WebElement ele)
	{
		JavascriptExecutor js=(JavascriptExecutor)driver;
		js.executeScript("arguments[0].scrollIntroView();", ele);
		
	}
	
	public static void click(WebDriver ldriver,WebElement locatorName)
	{
		Actions act= new Actions(ldriver);
		act.moveToElement(locatorName).click().build().perform();
		
	}
	public static boolean findElement(WebDriver ldriver,WebElement ele)
	{
		boolean flag=false;
		try {
			ele.isDisplayed();
			flag=true;
			
		}catch (Exception e)
		{
			flag= false;
		}
		finally
		{
			if(flag){
				System.out.println("Suceesfully found Element at");
			}else
			{
				System.out.println("The element is not found");
			}
		}
		return flag;
	}
	
	
	public static boolean isDisplayed(WebDriver ldriver,WebElement ele)
	{
		boolean flag=false;
		flag=findElement(ldriver,ele);
		if(flag)
		{
			flag=ele.isDisplayed();
			if(flag)
			{
				System.out.println("The element is Displayed");
			}
			else
			{
				System.out.println("the Element is not Dispalyed");
			}
		}
		else
		{
			System.out.println("NOT DISPLAYED");
		}
	
	return flag;
	}

	public static boolean type(WebElement ele,String text)throws Throwable
	{   boolean flag=false;
	try {
		flag=ele.isDisplayed();
		ele.sendKeys(text);
		
	}
	catch(Exception e)
	{
		System.out.println("Location not found");
		flag=false;
	}finally
	{
		if(flag)
			System.out.println("Successfully Updated");
		else
			System.out.println("unable to enter");
	}
	return flag; 
	}

	

}
