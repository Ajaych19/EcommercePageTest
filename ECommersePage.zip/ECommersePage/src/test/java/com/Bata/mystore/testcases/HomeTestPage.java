package com.Bata.mystore.testcases;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.Bata.mystore.base.BaseClass;
import com.Bata.mystore.pageObject.HomePage;
import com.Bata.mystore.pageObject.LoginPage;
import com.Bata.mystore.pageObject.indexPage;

import freemarker.ext.servlet.IncludePage;

public class HomeTestPage extends BaseClass{
        
	  
	indexPage currentIndexPage;
	LoginPage currentLoginPage;
	HomePage currentHomePage;
	
	 @BeforeMethod
	  public void setup()
	  {
		
		  LaunchApp();
		
	  }
	 @Test
	public void HomePageTest() throws Throwable
	{
		currentIndexPage=new indexPage();
		currentLoginPage=currentIndexPage.clickSignIn();
		currentHomePage=currentLoginPage.loginClick();
		
		Thread.sleep(100);
    	System.out.println("hello");
    	currentHomePage.SearchProduct();
		
	}
	
	
}
